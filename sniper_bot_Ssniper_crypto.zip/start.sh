#!/bin/bash
python main.py