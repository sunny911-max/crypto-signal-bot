#!/bin/bash
python3 crypto_rsi_bot.py