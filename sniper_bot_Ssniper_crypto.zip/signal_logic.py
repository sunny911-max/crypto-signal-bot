def check_signals():
    return ["✅ Test signal from Ssniper bot at $TEST"]