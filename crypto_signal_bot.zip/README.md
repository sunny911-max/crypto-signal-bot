# Crypto Signal Bot
This bot sends high-risk, short-timeframe crypto trading signals to Telegram based on RSI and volume analysis.